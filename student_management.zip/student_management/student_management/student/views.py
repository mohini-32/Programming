from django.shortcuts import render, HttpResponse, redirect
from .forms import StudentForm 
from .models import Student
from django.contrib import messages
from django.views.generic import ListView, UpdateView, DeleteView, CreateView
from django.urls import reverse_lazy

# from django import forms


# from django.shortcuts import render, HttpResponse
# 
# from . import forms 



# Create your views here.

#3 types of from in django

"""
1. HTML From
1. From API
1. Model From

"""

#This is for html forms
# def home(request):
#     print(request.POST)
#     if request.method == 'POST':
#         name = request.POST.get('name')
#         email = request.POST.get('email')
#         phone = request.POST.get('phone')
#         password = request.POST.get('password')
#         checkbox = request.POST.get('checkbox')
#         photo = request.FILES.get('photo')

#         if checkbox == 'on':
#             checkbox = True
#         else:
#             checkbox = False


#         student = models.Student(name=name, email=email, phone=phone, 
#         password=password, checkbox=checkbox, photo=photo)  #student class ar object make

#         student.save()  # student table a 1te record make
#         return HttpResponse('Student object created successfully')
    

#     return render(request,'student/index.html')



#This is for model form

def create_student(request):
    if request.method == 'POST':  
        form = StudentForm(request.POST, request.FILES)  
        if form.is_valid():  
            form.save()  
            messages.add_message(request, messages.SUCCESS, 'Student Created successfully.')

            return redirect('home')
        else:
            # If form is invalid, return the same form with errors
            return render(request, 'student/create_edit_student.html', {'form': form})  

    else:
        form = StudentForm()
    return render(request, 'student/create_edit_student.html', {'form': form})  



class CreateStudent(CreateView):
    form_class = StudentForm
    success_url = reverse_lazy('home')
    template_name = 'student/create_edit_student.html'

    def form_valid(self, form):
        messages.add_message(self.request, messages.SUCCESS, 'Student Created successfully.')
        return super().form_valid(form)


#for function base views
def home(request):
    students = Student.objects.all()
    # print('student',students)
    return render(request, 'student/index.html', {'students': students})



# for class based views
class StudentLists(ListView):
    model = Student
    template_name = 'student/index.html'
    context_object_name = 'students'


def update_student(request, id):
    student = Student.objects.get(id=id)
    form =  StudentForm(instance=student)   # USER AR AGER DATA DEYA FORM FILL UP
    

    if request.method == 'POST':
        form = StudentForm(request.POST, request.FILES, instance=student)
        if form.is_valid():
            form.save()
            messages.add_message(request, messages.SUCCESS, 'Student Updated successfully.')

            return redirect('home')
    return render(request, 'student/create_edit_student.html', {'form': form, 'edit': True})   



#
class UpdateStudentData(UpdateView):
    form_class = StudentForm
    model = Student
    template_name = 'student/create_edit_student.html'
    success_url = reverse_lazy('home')
    pk_url_kwarg = 'id'
    def form_valid(self, form):
        """If the form is valid, save the associated model."""
        messages.add_message(self.request, messages.SUCCESS, 'Student Updated successfully.')
        return super().form_valid(form)
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['edit'] = True
        return context
     
     



def delete_student(request, id):
    student = Student.objects.get(id=id)  # id=id wala student ke amra khuja bar korlam, 
    # tar object palam
    student.delete() 
    messages.add_message(request, messages.SUCCESS, 'Student Deleted successfully.')

       # oi student object delete korlam, 
    return redirect('home') # successfull holo take page redirect kore dea


class DeleteStudent(DeleteView):
    model = Student
    pk_url_kwarg = 'id'
    success_url = reverse_lazy('home')
    template_name = 'student/delete_student.html'

    def delete(self, request, *args, **kwargs):
            messages.add_message(request, messages.SUCCESS, 'Student Deleted successfully.')
            return super().delete(request, *args, **kwargs)




