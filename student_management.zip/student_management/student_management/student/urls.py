from django.contrib import admin
from django.urls import path, include
from . import views
from .views import update_student

urlpatterns = [
     # path('home/', views.home, name="home"), # function based
     path('home/', views.StudentLists.as_view(), name="home"), # class based
     # path('home/', views.StudentLists.as_view(), name="home"), # function based
     # path('create/', views.create_student, name="create_student"),
     path('create/', views.CreateStudent.as_view(), name="create_student"), # class base
     # path('edit/<int:id>/', views.update_student, name="update_student"), #function base
     path('edit/<int:id>/', views.UpdateStudentData.as_view(), name="update_student"), #class base
     # path('delete/<int:id>/', views.delete_student, name="delete_student"), # function based
     path('delete/<int:id>/', views.DeleteStudent.as_view(), name="delete_student"), # class based
]

# edit/1
# edit/2
# edit/3